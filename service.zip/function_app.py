
import os
import json
import logging
from datetime import datetime
import azure.functions as func
from azure.storage.blob import BlobServiceClient

# Import FastAPI app
from backend.main import app as fastapi_app

# Import core processing functions
from backend.core.document_extractor import extract_text_with_docintelligence
from backend.core.checkpoint_loader import load_checkpoints_from_blob
from backend.core.audit_logic import verify_checkpoints_with_ai
from backend.core.report_generator import generate_report

# ✅ Single top-level app instance
app = func.AsgiFunctionApp(app=fastapi_app, http_auth_level=func.AuthLevel.ANONYMOUS)

# Environment variables
BLOB_CONN_STR = os.getenv("AZURE_BLOB_CONN_STR")
BLOB_CONTAINER = os.getenv("BLOB_CONTAINER", "genaipoc")

if not BLOB_CONN_STR:
    logging.error("AZURE_BLOB_CONN_STR is not set; blob operations will fail")

blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
container_client = blob_service.get_container_client(BLOB_CONTAINER)

# ✅ Service Bus Trigger registered on the same app
@app.function_name(name="ProcessAuditMessage")
@app.service_bus_queue_trigger(
    arg_name="msg",
    queue_name=os.getenv("SERVICE_BUS_QUEUE"),
    connection="AZURE_SERVICE_BUS_CONN_STR"
)
async def process_audit_message(msg: func.ServiceBusMessage):
    try:
        raw = msg.get_body()
        if isinstance(raw, bytes):
            raw = raw.decode('utf-8')
        data = json.loads(raw)
        logging.info(f"Received Service Bus message: {data}")

        file_id = data.get('file_id')
        blob_name = data.get('blob_name')
        filename = data.get('filename')

        if not file_id or not blob_name or not filename:
            logging.error(f"Invalid message format: {data}")
            return

        blob_client = container_client.get_blob_client(blob_name)
        if not blob_client.exists():
            logging.error(f"Blob not found: {blob_name}")
            return

        logging.info(f"Downloading blob {blob_name}")
        file_bytes = blob_client.download_blob().readall()

        ext = (filename or "").lower().split(".")[-1]

        try:
            full_text = extract_text_with_docintelligence(file_bytes, ext)
        except Exception:
            logging.exception("Text extraction failed")
            full_text = None

        try:
            checkpoints = load_checkpoints_from_blob()
        except Exception:
            logging.exception("Loading checkpoints failed")
            checkpoints = []

        try:
            results = await verify_checkpoints_with_ai(checkpoints, full_text, file_bytes, ext)
        except Exception:
            logging.exception("verify_checkpoints_with_ai failed")
            results = []

        summary = {
            "total_checkpoints": len(checkpoints),
            "passed": sum(1 for r in results if r.get("Status") == "Pass"),
            "failed": sum(1 for r in results if r.get("Status") == "Fail")
        }

        try:
            report_buf = generate_report(filename, summary, results)
            report_path = f"reports/report_{file_id}.docx"
            container_client.upload_blob(report_path, report_buf.getvalue(), overwrite=True)
            logging.info(f"Uploaded report to {report_path}")
        except Exception:
            logging.exception("Report generation/upload failed")

        try:
            results_json = {
                "file_id": file_id,
                "summary": summary,
                "results": results,
                "timestamp": datetime.utcnow().isoformat(),
            }
            results_path = f"results/results_{file_id}.json"
            container_client.upload_blob(results_path, json.dumps(results_json, indent=2), overwrite=True)
            logging.info(f"Uploaded results JSON to {results_path}")
        except Exception:
            logging.exception("Uploading results JSON failed")

        logging.info(f"Processing completed for file_id={file_id}")

    except Exception as e:
        logging.exception(f"Unexpected failure in ProcessAuditMessage: {e}")