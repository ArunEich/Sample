
from fastapi import APIRouter, HTTPException
 
from fastapi.responses import FileResponse, JSONResponse
from backend.core.logger import log_upload, load_upload_logs
from fastapi import FastAPI, File, UploadFile, HTTPException, Form, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import os
import shutil
from typing import Optional
from datetime import datetime
import pandas as pd
import json
 
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse
from azure.storage.blob import BlobServiceClient
import os
import json
from typing import Optional
from datetime import datetime
import tempfile

# Initialize router
router = APIRouter(prefix="/report", tags=["Report"])

# Environment variables for Azure Blob Storage
BLOB_CONN_STR = os.getenv("AZURE_BLOB_CONN_STR")
BLOB_CONTAINER = os.getenv("BLOB_CONTAINER", "genaipoc")

# Initialize Blob Service Client
blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
container_client = blob_service.get_container_client(BLOB_CONTAINER)

# -----------------------------
# Endpoint: View detailed results
# -----------------------------
@router.get("/view/{file_id}")
async def view_report(file_id: str):
    """Return detailed results (summary + checkpoints) as JSON from Blob Storage"""
    blob_name = f"results/results_{file_id}.json"
    # blob_name= f"uploads/jyo_20251113_105637_2129bbc1_Sample_1.0.docx"
    print("Hi")
    try:
        blob_client = container_client.get_blob_client(blob_name)
        print("check")
        stream = blob_client.download_blob()
        print("check2")
        results_data = json.loads(stream.readall())
        print("check3")
        return JSONResponse(content=results_data)
        
        
        # # Read a small chunk to confirm download works
        # data = stream.readall()  # Or stream.readinto() for large files
        # print(f"Downloaded {len(data)} bytes")
        
        # return {"message": "File downloaded successfully", "size": len(data)}
    except Exception:
        raise HTTPException(status_code=404, detail="Results not found in Blob Storage")


# -----------------------------
# Endpoint: Download generated report
# -----------------------------
@router.get("/download/{file_id}")
async def download_report(file_id: str):
    """Download the report as .docx from Blob Storage"""
    blob_name = f"reports/report_{file_id}.docx"
    print("Hi_1")
    try:
        blob_client = container_client.get_blob_client(blob_name)
        stream = blob_client.download_blob()

        # Save to temporary file for FileResponse
        temp_dir = tempfile.gettempdir()
        temp_path = os.path.join(temp_dir, f"report_{file_id}.docx")
        with open(temp_path, "wb") as f:
            f.write(stream.readall())

        return FileResponse(
            temp_path,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            filename=f"Validation_Report_{file_id}.docx"
        )
    except Exception:
        raise HTTPException(status_code=404, detail="Report not found in Blob Storage")

# -----------------------------
# Endpoint: Dashboard - Get upload history
# -----------------------------
from backend.core.logger import load_upload_logs

@router.get("/dashboard")
async def get_user_uploads(username: Optional[str] = Query(None)):
    """Get upload history for a specific user or all users from Azure Blob Storage."""
    logs_data = load_upload_logs()
    if username:
        user_records = [record for record in logs_data if record.get("User") == username]
        data = user_records
    else:
        data = logs_data
    return JSONResponse(content={"dashboard": data})

# -----------------------------
# Endpoint: Health Check
# -----------------------------
@router.get("/health")
async def health_check():
    """Simple health check for the report router"""
    return JSONResponse(content={
        "status": "healthy",
        "timestamp": datetime.now().isoformat()
    })