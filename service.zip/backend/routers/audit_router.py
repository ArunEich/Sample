# backend/routers/audit_router.py
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
import os, json, traceback
from datetime import datetime
import uuid
from dotenv import load_dotenv
load_dotenv()

from azure.storage.blob import BlobServiceClient
from backend.utils.servicebus_sender import send_message_to_queue
from backend.core.logger import log_upload  # ✅ Added import

router = APIRouter(prefix="/audit", tags=["Audit"])

# Azure Blob configuration
BLOB_CONN_STR = os.getenv("AZURE_BLOB_CONN_STR")
BLOB_CONTAINER = os.getenv("BLOB_CONTAINER", "genaipoc")

if not BLOB_CONN_STR:
    raise RuntimeError("AZURE_BLOB_CONN_STR not set in environment")

blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
container_client = blob_service.get_container_client(BLOB_CONTAINER)

@router.post("/run")
async def run_audit(username: str = Form(...), file: UploadFile = File(...)):
    try:
        # Validate file type
        if not file.filename.lower().endswith((".pdf", ".docx")):
            raise HTTPException(status_code=400, detail="Only PDF and DOCX are supported")

        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        file_id = f"{username}_{timestamp}_{uuid.uuid4().hex[:8]}"
        blob_name = f"uploads/{file_id}_{file.filename}"

        # Upload file to Azure Blob
        try:
            content = await file.read()
            blob_client = container_client.get_blob_client(blob_name)
            blob_client.upload_blob(content, overwrite=True)
            blob_url = blob_client.url

            # Log upload for dashboard
            log_upload(user=username, file_name=file.filename)

        except Exception as e:
            traceback.print_exc()
            raise HTTPException(status_code=500, detail=f"Failed to upload to Blob: {str(e)}")

        # Prepare message for Service Bus
        message_data = {
            "file_id": file_id,
            "username": username,
            "filename": file.filename,
            "blob_container": BLOB_CONTAINER,
            "blob_name": blob_name,
            "blob_url": blob_url,
            "timestamp": timestamp
        }

        # Send message to Service Bus
        try:
            print("DEBUG: Calling send_message_to_queue()")
            send_message_to_queue(message_data)
        except Exception as e:
            traceback.print_exc()
            # Optionally delete blob if sending message fails
            try:
                container_client.delete_blob(blob_name)
            except Exception:
                pass
            raise HTTPException(status_code=500, detail=f"Failed to send Service Bus message: {str(e)}")

        return JSONResponse(content={
            "status": "success",
            "message": "File uploaded and processing message sent.",
            "file_id": file_id,
            "blob_url": blob_url
        })

    except HTTPException as http_err:
        # Re-raise HTTPException for FastAPI to handle
        raise http_err
    except Exception as e:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")