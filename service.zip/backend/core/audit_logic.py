# backend/core/audit_logic.py
from backend.core.ai_reviewer import (
    classify_rule_type, check_with_text_engine, check_with_vision_engine, check_with_hybrid_engine
)
from backend.utils.file_ops import pdf_bytes_to_images, convert_docx_to_pdf_bytes

def determine_status_from_recommendation(recommendation: str) -> str:
    rec_lower = recommendation.lower()
    if "status: pass" in rec_lower:
        return "Pass"
    if "status: fail" in rec_lower:
        return "Fail"
    # heuristics
    if any(p in rec_lower for p in ["checkpoint satisfied", "requirement satisfied", "checkpoint met"]):
        return "Pass"
    return "Fail"

async def verify_checkpoints_with_ai(checkpoints, full_text: str, file_bytes: bytes, file_ext: str):
    results = []
    page_images = []
    # convert to images if available
    try:
        if file_ext == "pdf":
            page_images = pdf_bytes_to_images(file_bytes, dpi=150)
        elif file_ext == "docx":
            pdf_bytes = convert_docx_to_pdf_bytes(file_bytes)
            if pdf_bytes:
                page_images = pdf_bytes_to_images(pdf_bytes, dpi=150)
    except Exception as e:
        page_images = []

    for idx, checkpoint in enumerate(checkpoints, start=1):
        try:
            rule_type = classify_rule_type(checkpoint)
            if rule_type == "text_rule":
                recommendation = check_with_text_engine(checkpoint, full_text)
                status = determine_status_from_recommendation(recommendation)
            elif rule_type == "visual_rule":
                if page_images:
                    vision_results, status = check_with_vision_engine(checkpoint, page_images)
                    recommendation = "\n".join(vision_results)
                else:
                    status = "Fail"
                    recommendation = "Visual analysis not available"
            elif rule_type == "hybrid_rule":
                if page_images:
                    hybrid = check_with_hybrid_engine(checkpoint, full_text, page_images)
                    recommendation = recommendation = f"Text: {hybrid['text_result']}\nVision: {hybrid['vision_results']}"

                    status = hybrid["status"]
                else:
                    recommendation = check_with_text_engine(checkpoint, full_text) + "\n(Visual unavailable)"
                    status = determine_status_from_recommendation(recommendation)
            else:
                status = "Fail"
                recommendation = "Unknown rule type"
        except Exception as e:
            status = "Fail"
            recommendation = f"Error processing checkpoint: {e}"

        results.append({
            "S_No": idx,
            "Checkpoint": checkpoint,
            "Status": status,
            "Recommendation": recommendation
        })

    return results
