# # backend/core/document_extractor.py
# from io import BytesIO
# from docx import Document as DocxDocument
# from backend.utils.azure_clients import document_client

# def extract_pdf_content(file_bytes: bytes) -> str:
#     if document_client is None:
#         raise RuntimeError("DocumentAnalysisClient not initialized. Check AZURE_ENDPOINT and AZURE_KEY in .env")
#     poller = document_client.begin_analyze_document("prebuilt-layout", file_bytes)
#     result = poller.result()
#     full_text = result.content or ""

#     tables_text = []
#     for t_index, table in enumerate(result.tables, start=1):
#         tables_text.append(f"\n[Table {t_index}]\n")
#         rows = {}
#         for cell in table.cells:
#             rows.setdefault(cell.row_index, {})[cell.column_index] = cell.content.strip().replace("\n", " ")
#         for row_idx in sorted(rows.keys()):
#             row = rows[row_idx]
#             row_text = " | ".join([row.get(col_idx, "") for col_idx in sorted(row.keys())])
#             tables_text.append(row_text)
#         tables_text.append("")
#     tables_combined = "\n".join(tables_text)
#     return f"{full_text}\n\nExtracted Tables:\n{tables_combined}"

# def extract_docx_content(file_bytes: bytes) -> str:
#     doc = DocxDocument(BytesIO(file_bytes))
#     paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]

#     # include headers/footers (if present)
#     for section in doc.sections:
#         header = section.header
#         footer = section.footer
#         if header:
#             for p in header.paragraphs:
#                 if p.text.strip():
#                     paragraphs.append("[HEADER] " + p.text.strip())
#         if footer:
#             for p in footer.paragraphs:
#                 if p.text.strip():
#                     paragraphs.append("[FOOTER] " + p.text.strip())

#     full_text = "\n".join(paragraphs)
#     tables_text = []
#     for t_index, table in enumerate(doc.tables, start=1):
#         tables_text.append(f"\n[Table {t_index}]\n")
#         for row in table.rows:
#             row_text = " | ".join([cell.text.strip() for cell in row.cells])
#             tables_text.append(row_text)
#         tables_text.append("")
#     tables_combined = "\n".join(tables_text)
#     return f"{full_text}\n\nExtracted Tables:\n{tables_combined}"
from io import BytesIO
from typing import Literal
from docx import Document as DocxDocument
from backend.utils.azure_clients import document_client

def extract_pdf_content(file_bytes: bytes) -> str:
    """
    Extract text and tables from a PDF using Azure Document Intelligence.
    """
    if document_client is None:
        raise RuntimeError("DocumentAnalysisClient not initialized. Check AZURE_ENDPOINT and AZURE_KEY in .env")

    poller = document_client.begin_analyze_document("prebuilt-layout", file_bytes)
    result = poller.result()
    full_text = result.content or ""

    tables_text = []
    for t_index, table in enumerate(result.tables, start=1):
        tables_text.append(f"\n[Table {t_index}]\n")
        rows = {}
        for cell in table.cells:
            rows.setdefault(cell.row_index, {})[cell.column_index] = cell.content.strip().replace("\n", " ")
        for row_idx in sorted(rows.keys()):
            row = rows[row_idx]
            row_text = " | ".join([row.get(col_idx, "") for col_idx in sorted(row.keys())])
            tables_text.append(row_text)
        tables_text.append("")
    tables_combined = "\n".join(tables_text)
    return f"{full_text}\n\nExtracted Tables:\n{tables_combined}"


def extract_docx_content(file_bytes: bytes) -> str:
    """
    Extract text and tables from a DOCX file.
    """
    doc = DocxDocument(BytesIO(file_bytes))
    paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]

    # Include headers and footers
    for section in doc.sections:
        header = section.header
        footer = section.footer
        if header:
            for p in header.paragraphs:
                if p.text.strip():
                    paragraphs.append("[HEADER] " + p.text.strip())
        if footer:
            for p in footer.paragraphs:
                if p.text.strip():
                    paragraphs.append("[FOOTER] " + p.text.strip())

    full_text = "\n".join(paragraphs)

    # Extract tables
    tables_text = []
    for t_index, table in enumerate(doc.tables, start=1):
        tables_text.append(f"\n[Table {t_index}]\n")
        for row in table.rows:
            row_text = " | ".join([cell.text.strip() for cell in row.cells])
            tables_text.append(row_text)
        tables_text.append("")
    tables_combined = "\n".join(tables_text)
    return f"{full_text}\n\nExtracted Tables:\n{tables_combined}"


def extract_text_with_docintelligence(file_bytes: bytes, file_type: Literal["pdf", "docx"]) -> str:
    """
    Unified function to extract text using Azure Document Intelligence or DOCX parser.
    :param file_bytes: File content in bytes
    :param file_type: 'pdf' or 'docx'
    :return: Extracted text
    """
    if file_type.lower() == "pdf":
        return extract_pdf_content(file_bytes)
    elif file_type.lower() == "docx":
        return extract_docx_content(file_bytes)
    else:
        raise ValueError(f"Unsupported file type: {file_type}")
