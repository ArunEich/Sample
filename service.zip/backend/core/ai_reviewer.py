# backend/core/ai_reviewer.py
from backend.utils.azure_clients import openai_client, OPENAI_DEPLOYMENT
from io import BytesIO
import base64

def classify_rule_type(checkpoint: str) -> str:
    """Return 'text_rule' | 'visual_rule' | 'hybrid_rule'"""
    if openai_client is None:
        return "text_rule"
    prompt = f"""
You are an assistant that classifies audit checkpoints.

Checkpoint:
"{checkpoint}"

Decide the rule type:
- text_rule: Can be verified only from text.
- visual_rule: Needs visual/layout check only (logo, page numbers, formatting, signatures).
- hybrid_rule: Needs both text + visual validation.

Answer with only one word: text_rule, visual_rule, or hybrid_rule.
"""
    try:
        resp = openai_client.chat.completions.create(
            model=OPENAI_DEPLOYMENT,
            messages=[{"role":"user","content":prompt}],
            temperature=0,
            max_tokens=10
        )
        return resp.choices[0].message.content.strip().lower()
    except Exception:
        return "text_rule"

def check_with_text_engine(checkpoint: str, document_text: str) -> str:
    if openai_client is None:
        return "STATUS: FAIL\n(Error: OpenAI client not configured)"
    prompt = f"""
You are auditing a document.

Document Text:
{document_text}

Rule:
{checkpoint}

Instructions:
- Check if this rule is satisfied in the text (including [HEADER]/[FOOTER]/[IMAGE] placeholders).
- End with one line: STATUS: PASS or STATUS: FAIL
- If FAIL, add a short recommendation.
"""
    try:
        resp = openai_client.chat.completions.create(
            model=OPENAI_DEPLOYMENT,
            messages=[{"role":"user","content":prompt}],
            temperature=0,
            max_tokens=300
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return f"Error in text engine: {e}\nSTATUS: FAIL"

def encode_image_to_base64(image):
    buffered = BytesIO()
    image.save(buffered, format="PNG")
    return base64.b64encode(buffered.getvalue()).decode("utf-8")

def check_with_vision_engine(checkpoint: str, page_images):
    """Sends first page image + prompt to OpenAI multimodal call; returns textual analysis and aggregated status."""
    results = []
    if openai_client is None or not page_images:
        return ["Error: vision or images not available"], "Fail"

    base_prompt = (
        "You are a document compliance checker.\n\n"
        "Checkpoint Rule:\n{checkpoint}\n\n"
        "Task: Review the provided page image and verify whether the header contains the required elements.\n"
        "For each required element, state Found or Missing. After findings, give STATUS: PASS or STATUS: FAIL.\n"
    ).format(checkpoint=checkpoint)

    try:
        b64 = encode_image_to_base64(page_images[0])
        # create message – use same multimodal format you had previously
        response = openai_client.chat.completions.create(
            model=OPENAI_DEPLOYMENT,
            messages=[{
                "role": "user",
                "content": [
                    {"type": "text", "text": base_prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}}
                ]
            }],
            temperature=0,
            max_tokens=400
        )
        text = response.choices[0].message.content.strip()
        results.append(text)
    except Exception as e:
        results.append(f"Error analyzing image: {e}")

    final_status = "Fail"
    for r in results:
        if "status: pass" in r.lower():
            final_status = "Pass"
            break
    return results, final_status

def check_with_hybrid_engine(checkpoint: str, document_text: str, page_images):
    text_result = check_with_text_engine(checkpoint, document_text)
    text_status = "Pass" if "status: pass" in text_result.lower() else "Fail"
    vision_results, vision_status = check_with_vision_engine(checkpoint, page_images)
    final_status = "Pass" if (text_status == "Pass" and vision_status == "Pass") else "Fail"
    return {
        "text_result": text_result,
        "vision_results": vision_results,
        "status": final_status
    }
