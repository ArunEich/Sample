# backend/core/checkpoint_loader.py
import os
import pandas as pd

def load_checkpoints():
    # Excel path in project data folder
    excel_path = os.path.join(os.getcwd(), "data", "Rules BD Audit Automation copy.xlsx")
    try:
        df = pd.read_excel(excel_path)
        if "checkpointDesc" not in df.columns:
            raise ValueError("Excel must have 'checkpointDesc' column")
        return df["checkpointDesc"].dropna().tolist()
    except FileNotFoundError:
        # fallback default rules if the file doesn't exist locally
        return [
            "Document should have BD logo",
            "Document should contain project name",
            "Document should have proper page numbering",
            "Document should have SRA information",
            "Document should follow proper formatting guidelines"
        ]
