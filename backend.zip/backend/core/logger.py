# backend/core/logger.py
import os
import pandas as pd
from datetime import datetime

UPLOAD_LOG_FILE = os.getenv("UPLOAD_LOG_FILE", os.path.join(os.getcwd(), "data", "upload_logs.csv"))

def init_log_file():
    os.makedirs(os.path.dirname(UPLOAD_LOG_FILE), exist_ok=True)
    if not os.path.exists(UPLOAD_LOG_FILE):
        pd.DataFrame(columns=["User", "File Name", "Upload Time"]).to_csv(UPLOAD_LOG_FILE, index=False)

def log_upload(user: str, file_name: str):
    init_log_file()
    upload_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    new_record = pd.DataFrame([[user, file_name, upload_time]], columns=["User", "File Name", "Upload Time"])
    new_record.to_csv(UPLOAD_LOG_FILE, mode="a", header=False, index=False)

def load_upload_logs():
    init_log_file()
    df = pd.read_csv(UPLOAD_LOG_FILE)
    if not df.empty:
        df["Upload Count"] = df.groupby(["User", "File Name"]).cumcount() + 1
    else:
        df["Upload Count"] = []
    return df
