# backend/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from backend.routers import audit_router, report_router
from backend.core.logger import init_log_file

@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup: ensure log file exists
    init_log_file()
    yield
    # shutdown: nothing special yet

app = FastAPI(title="BD Audit Automation API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # adjust in prod
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True
)

app.include_router(audit_router.router)
app.include_router(report_router.router)

@app.get("/")
def root():
    return {"message": "BD Audit Automation API running"}
