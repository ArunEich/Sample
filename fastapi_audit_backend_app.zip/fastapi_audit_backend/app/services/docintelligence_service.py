from typing import Any
from app.config import settings
import logging

logger = logging.getLogger(__name__)

class DocIntelligenceService:
    def __init__(self):
        # Check if the Document Intelligence (Form Recognizer) credentials are provided
        if not settings.DOCINTELLIGENCE_ENDPOINT or not settings.DOCINTELLIGENCE_KEY:
            logger.warning("Document Intelligence credentials not configured; any calls will raise")
            self.enabled = False
        else:
            self.enabled = True
            # Import the DocumentAnalysisClient late to avoid hard dependency during local dev if not configured
            from azure.ai.formrecognizer import DocumentAnalysisClient
            from azure.core.credentials import AzureKeyCredential
            self.client = DocumentAnalysisClient(
                endpoint=settings.DOCINTELLIGENCE_ENDPOINT,
                credential=AzureKeyCredential(settings.DOCINTELLIGENCE_KEY),
            )
            logger.info("Document Intelligence service initialized successfully.")

    def analyze_bytes(self, content: bytes, content_type: str = "application/pdf") -> Any:
        """Analyze document bytes using Azure Document Intelligence."""
        if not self.enabled:
            raise RuntimeError("Document Intelligence not configured.")
        
        try:
            # Process PDF or DOCX content depending on the content_type
            if content_type == "application/pdf":
                # Analyze PDF content
                logger.info("Analyzing PDF content.")
                poller = self.client.begin_analyze_document("prebuilt-document", content)
            elif content_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                # Analyze DOCX content
                logger.info("Analyzing DOCX content.")
                poller = self.client.begin_analyze_document("prebuilt-document", content)
            else:
                logger.error(f"Unsupported content type: {content_type}")
                raise ValueError(f"Unsupported content type: {content_type}")

            # Wait for the operation to complete
            result = poller.result()

            # Return the result
            return result
        except Exception as e:
            logger.error(f"Document analysis failed: {str(e)}")
            raise
