# backend/app/services/servicebus_publisher.py (this is a dummy placeholder file)
import json
from azure.servicebus import ServiceBusClient, ServiceBusMessage
from app.config import settings
import logging


logger = logging.getLogger(__name__)


class ServiceBusPublisher:
    def __init__(self):
        if not settings.AZURE_SERVICE_BUS_CONNECTION_STRING:
            raise RuntimeError("AZURE_SERVICE_BUS_CONNECTION_STRING not configured")
        self.client = ServiceBusClient.from_connection_string(settings.AZURE_SERVICE_BUS_CONNECTION_STRING)
        self.queue_name = settings.SERVICE_BUS_QUEUE_NAME


    def publish(self, payload: dict):
        msg = ServiceBusMessage(json.dumps(payload))
        with self.client.get_queue_sender(self.queue_name) as sender:
            sender.send_messages(msg)
        logger.info("Published message to Service Bus")