import logging
import json
from app.config import settings

logger = logging.getLogger(__name__)

class AIService:
    def __init__(self):
        """Initialize AI service using Azure OpenAI API."""
        if not settings.AZURE_OPENAI_ENDPOINT or not settings.AZURE_OPENAI_KEY or not settings.AZURE_OPENAI_DEPLOYMENT:
            logger.warning("Azure OpenAI credentials not configured; any calls will raise.")
            self.enabled = False
        else:
            self.enabled = True
            # Import the OpenAI client only if it's enabled to avoid unnecessary dependencies in local dev
            from azure.ai.openai import OpenAIClient
            from azure.core.credentials import AzureKeyCredential
            self.client = OpenAIClient(settings.AZURE_OPENAI_ENDPOINT, AzureKeyCredential(settings.AZURE_OPENAI_KEY))
            self.deployment = settings.AZURE_OPENAI_DEPLOYMENT
            logger.info("Azure OpenAI service initialized successfully.")

    def summarize(self, texts: list, max_tokens: int = 200) -> str:
        """
        Summarize the provided list of texts using Azure OpenAI's chat-based model.
        This method will concatenate the texts and ask OpenAI to generate a summary.
        """
        if not self.enabled:
            # Fallback for non-production environments or missing credentials
            logger.warning("Azure OpenAI is not enabled. Using basic concatenation as fallback.")
            return "\n".join(texts[:5])  # Basic fallback: concatenate the first 5 texts

        try:
            # Prepare the prompt
            prompt = "Summarize the following document content in 3 concise bullet points:\n\n"
            prompt += "\n\n----\n\n".join(texts)

            # Make the request to OpenAI
            response = self.client.get_chat_completions(
                model=self.deployment,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens
            )
            summary = response.choices[0].message.content
            return summary
        except Exception as e:
            logger.error(f"Failed to summarize text: {e}")
            raise

    def evaluate_checkpoint(self, checkpoint_text: str, doc_excerpt: str) -> dict:
        """
        Evaluate a checkpoint against a document excerpt. Returns the evaluation result as a JSON-like dictionary.
        """
        if not self.enabled:
            # Fallback for non-production environments or missing credentials
            logger.warning("Azure OpenAI is not enabled. Using simple heuristic for checkpoint evaluation.")
            # Simple keyword match (fallback logic)
            matched = any(word.lower() in doc_excerpt.lower() for word in checkpoint_text.split())
            return {
                "status": "Pass" if matched else "Fail",
                "recommendation": "Check presence of keywords in document."
            }

        try:
            # Prepare the prompt for AI to evaluate the checkpoint
            prompt = (
                f"You are an audit assistant. Given the checkpoint: '{checkpoint_text}' "
                f"and the document excerpt: '{doc_excerpt}',\n"
                f"Return a JSON object with fields: status ('Pass' or 'Fail') and "
                f"recommendation (one short sentence)."
            )

            # Make the request to OpenAI
            response = self.client.get_chat_completions(
                model=self.deployment,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=150
            )

            # Process and return the result
            result = response.choices[0].message.content
            try:
                # Attempt to parse the response as JSON
                parsed_result = json.loads(result)
            except json.JSONDecodeError:
                # If parsing fails, just return the raw result
                parsed_result = {"status": "Fail", "recommendation": result}

            return parsed_result
        except Exception as e:
            logger.error(f"Failed to evaluate checkpoint: {e}")
            return {"status": "Fail", "recommendation": f"Error: {str(e)}"}
