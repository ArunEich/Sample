from azure.storage.blob import BlobServiceClient
from app.config import settings
import logging


logger = logging.getLogger(__name__)


class BlobService:
    def __init__(self):
        if not settings.AZURE_STORAGE_CONNECTION_STRING:
            raise RuntimeError("AZURE_STORAGE_CONNECTION_STRING not configured")
        self.client = BlobServiceClient.from_connection_string(settings.AZURE_STORAGE_CONNECTION_STRING)


    def upload_bytes(self, container: str, blob_name: str, data: bytes, overwrite: bool = True):
        container_client = self.client.get_container_client(container)
        try:
            container_client.create_container()
        except Exception:
            pass
        blob_client = container_client.get_blob_client(blob_name)
        blob_client.upload_blob(data, overwrite=overwrite)
        logger.info(f"Uploaded blob {container}/{blob_name}")


def download_bytes(self, container: str, blob_name: str) -> bytes:
    blob_client = self.client.get_blob_client(container=container, blob=blob_name)
    stream = blob_client.download_blob()
    return stream.readall()


def download_to_path(self, container: str, blob_name: str, path: str):
    data = self.download_bytes(container, blob_name)
    with open(path, "wb") as f:
        f.write(data)
    return path