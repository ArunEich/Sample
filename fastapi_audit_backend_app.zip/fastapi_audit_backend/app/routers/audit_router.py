from fastapi import APIRouter, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
import os
import json
from datetime import datetime
import uuid

from app.services.blob_service import BlobService
from app.services.servicebus import ServiceBusPublisher
from app.core.checkpoint_loader import load_checkpoints
from app.core.audit_logic import verify_checkpoints_with_ai
from app.core.report_generator import generate_report
from app.config import settings
from app.utils.file_ops import save_uploaded_file

router = APIRouter(prefix="/audit", tags=["Audit"])

# Local directories for storing uploaded files temporarily
UPLOAD_DIR = os.path.join(os.getcwd(), "uploads")
OUTPUT_DIR = os.path.join(os.getcwd(), "output")

# Ensure required directories exist
for directory in [UPLOAD_DIR, OUTPUT_DIR]:
    os.makedirs(directory, exist_ok=True)

# Initialize services
blob_service = BlobService()
publisher = ServiceBusPublisher()

@router.post("/run")
async def run_audit(username: str = Form(...), file: UploadFile = File(...), background_tasks: BackgroundTasks):
    """
    Main audit endpoint:
    1. Receives file and username as input
    2. Saves the file temporarily and uploads it to Azure Blob Storage
    3. Publishes an audit job to Service Bus for asynchronous processing
    4. Returns a status message with the job file ID
    """
    if not file.filename.lower().endswith((".pdf", ".docx")):
        raise HTTPException(status_code=400, detail="Only PDF and DOCX files are supported")

    # Generate unique file ID for tracking
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_id = f"{username}_{timestamp}_{uuid.uuid4()}"
    file_path = os.path.join(UPLOAD_DIR, file_id)

    # Save uploaded file temporarily
    file_bytes = await file.read()
    save_uploaded_file(file_bytes, file_path)

    # Upload to Azure Blob Storage
    blob_path = f"{file_id}/{file.filename}"
    blob_service.upload_bytes(container=settings.BLOB_CONTAINER_UPLOADS, blob_name=blob_path, data=file_bytes)

    # Load predefined audit checkpoints (rules) from Blob Storage
    checkpoints = load_checkpoints()

    # Publish the audit job to Service Bus for asynchronous processing by Azure Function
    message = {
        "file_id": file_id,
        "blob_path": blob_path,
        "username": username,
        "filename": file.filename,
        "timestamp": datetime.now().isoformat(),
    }
    background_tasks.add_task(publisher.publish, message)

    # Response with file ID and status
    return JSONResponse(
        content={
            "status": "queued",
            "file_id": file_id,
            "message": "Audit job has been queued for processing."
        }
    )


@router.get("/status/{file_id}")
async def get_audit_status(file_id: str):
    """
    Endpoint to check the status of the audit job using the file_id.
    The status of the audit job is returned after it's been processed.
    """
    results_path = os.path.join(OUTPUT_DIR, f"results_{file_id}.json")
    
    if not os.path.exists(results_path):
        raise HTTPException(status_code=404, detail="Audit results not found. Please wait for the job to complete.")

    # Read the results from the saved file
    with open(results_path, "r") as f:
        results_data = json.load(f)

    return JSONResponse(content=results_data)


@router.get("/download/{file_id}")
async def download_report(file_id: str):
    """
    Endpoint to download the generated audit report in DOCX format.
    """
    report_path = os.path.join(OUTPUT_DIR, f"report_{file_id}.docx")

    if not os.path.exists(report_path):
        raise HTTPException(status_code=404, detail="Report not found. Please wait for the audit to complete.")

    # Return the file as a response for download
    return JSONResponse(
        content={
            "status": "success",
            "file_url": f"/files/{file_id}/report.docx"
        }
    )


@router.get("/uploads")
async def get_uploads(username: str = None):
    """
    Get the history of file uploads for a specific user or all users.
    """
    upload_log_path = os.path.join(OUTPUT_DIR, "upload_logs.json")

    if not os.path.exists(upload_log_path):
        raise HTTPException(status_code=404, detail="Upload log not found.")
    
    with open(upload_log_path, "r") as f:
        upload_logs = json.load(f)

    if username:
        # Filter uploads by username
        user_uploads = [log for log in upload_logs if log['username'] == username]
        return JSONResponse(content={"uploads": user_uploads})
    
    return JSONResponse(content={"uploads": upload_logs})

