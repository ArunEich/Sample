from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse
import os
import json
from typing import Optional
from app.config import settings


router = APIRouter(prefix="/report", tags=["Report"])
OUTPUT_DIR = os.path.join(os.getcwd(), "output")




@router.get("/view/{file_id}")
async def view_report(file_id: str):
    results_path = os.path.join(OUTPUT_DIR, f"results_{file_id}.json")
    if not os.path.exists(results_path):
        raise HTTPException(status_code=404, detail="Results not found")
    with open(results_path, "r") as f:
        return JSONResponse(content=json.load(f))




@router.get("/download/{file_id}")
async def download_report(file_id: str):
    report_path = os.path.join(OUTPUT_DIR, f"report_{file_id}.docx")
    if not os.path.exists(report_path):
        raise HTTPException(status_code=404, detail="Report not found")
    return FileResponse(report_path, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document", filename=f"Validation_Report_{file_id}.docx")




@router.get("/uploads")
async def get_uploads(username: Optional[str] = Query(None)):
# For a production app, replace this with a proper DB or Table Storage listing
    uploads_path = os.path.join(OUTPUT_DIR, "upload_logs.json")
    if not os.path.exists(uploads_path):
        return JSONResponse(content={"uploads": []})
    with open(uploads_path, "r") as f:
        all_uploads = json.load(f)
    if username:
        filtered = [u for u in all_uploads if u.get("username", "").lower() == username.lower()]
        return JSONResponse(content={"uploads": filtered})
    return JSONResponse(content={"uploads": all_uploads})