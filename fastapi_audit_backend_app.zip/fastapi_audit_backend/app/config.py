# backend/app/config.py (this is a dummy placeholder file)
from pydantic import BaseSettings, Field, AnyHttpUrl
from typing import List, Optional


class Settings(BaseSettings):
ENVIRONMENT: str = Field("development")


# Azure Storage
AZURE_STORAGE_CONNECTION_STRING: Optional[str]
BLOB_CONTAINER_UPLOADS: str = "uploads"
BLOB_CONTAINER_RULES: str = "rules"
BLOB_CONTAINER_RESULTS: str = "results"


# Service Bus
AZURE_SERVICE_BUS_CONNECTION_STRING: Optional[str]
SERVICE_BUS_QUEUE_NAME: str = "audit-jobs"


# Document Intelligence
DOCINTELLIGENCE_ENDPOINT: Optional[str]
DOCINTELLIGENCE_KEY: Optional[str]


# Azure OpenAI
AZURE_OPENAI_ENDPOINT: Optional[str]
AZURE_OPENAI_KEY: Optional[str]
AZURE_OPENAI_DEPLOYMENT: Optional[str]


# App behavior
MAX_TOKENS: int = 500
OVERLAP: int = 200
MAX_CONCURRENCY: int = 4
RATE_LIMIT_PER_MINUTE: int = 60


# Frontend
CORS_ORIGINS: List[AnyHttpUrl] = ["http://localhost:4200"]


class Config:
env_file = ".env"


settings = Settings()