# backend/app/utils/file_ops.py (this is a dummy placeholder file)
import os
import tempfile
import subprocess
from io import BytesIO
import logging

logger = logging.getLogger(__name__)

def save_uploaded_file(file_bytes: bytes, file_path: str) -> str:
    """Save the uploaded file as bytes to the given file path."""
    try:
        with open(file_path, "wb") as f:
            f.write(file_bytes)
        logger.info(f"File saved at: {file_path}")
        return file_path
    except Exception as e:
        logger.error(f"Failed to save file: {e}")
        raise

def convert_docx_to_pdf_bytes(docx_bytes: bytes) -> bytes:
    """Convert a DOCX file to PDF using LibreOffice in headless mode."""
    fd, path = tempfile.mkstemp(suffix='.docx')
    os.close(fd)
    with open(path, 'wb') as f:
        f.write(docx_bytes)
    
    out_pdf = path.replace('.docx', '.pdf')
    
    try:
        subprocess.check_call(['libreoffice', '--headless', '--convert-to', 'pdf', path, '--outdir', os.path.dirname(path)])
        with open(out_pdf, 'rb') as f:
            data = f.read()
        logger.info(f"Conversion successful: {out_pdf}")
    except Exception as e:
        logger.error(f"Conversion failed: {e}")
        raise
    finally:
        try:
            os.remove(path)
            os.remove(out_pdf)
        except Exception as cleanup_err:
            logger.warning(f"Error cleaning up temporary files: {cleanup_err}")
    
    return data

def save_pdf_images(pdf_bytes: bytes, save_dir: str, file_id: str) -> None:
    """Convert PDF to images and save each page as an image file."""
    try:
        import fitz  # PyMuPDF
    except ImportError:
        logger.error("PyMuPDF is not installed. Install it to extract images from PDFs.")
        raise
    
    try:
        pdf_path = os.path.join(save_dir, f"{file_id}.pdf")
        with open(pdf_path, "wb") as f:
            f.write(pdf_bytes)

        doc = fitz.open(pdf_path)
        for page_num in range(doc.page_count):
            page = doc.load_page(page_num)
            image = page.get_pixmap()
            img_path = os.path.join(save_dir, f"{file_id}_page_{page_num + 1}.png")
            image.save(img_path)
            logger.info(f"Saved image for page {page_num + 1}: {img_path}")
    except Exception as e:
        logger.error(f"Failed to extract PDF images: {e}")
        raise

def read_file_content(file_path: str) -> bytes:
    """Read the content of a file as bytes."""
    try:
        with open(file_path, "rb") as f:
            return f.read()
    except Exception as e:
        logger.error(f"Error reading file {file_path}: {e}")
        raise
