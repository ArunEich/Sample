# backend/app/core/checkpoint_loader.py (this is a dummy placeholder file)
import io
import pandas as pd
from app.services.blob_service import BlobService
from app.config import settings
import logging

logger = logging.getLogger(__name__)

def load_checkpoints() -> list:
    """Load audit checkpoints from the rules Excel in Blob Storage."""
    blob_svc = BlobService()
    blob_name = "Rules BD Audit Automation.xlsx"  # Modify this to match your exact blob name

    try:
        blob_data = blob_svc.download_bytes(settings.BLOB_CONTAINER_RULES, blob_name)
        df = pd.read_excel(io.BytesIO(blob_data))
        checkpoints = []
        
        # Assuming 'Serial' and 'Checkpoint' columns exist in the Excel file
        for idx, row in df.iterrows():
            checkpoints.append({
                "serial": int(row.get("Serial", idx + 1)),
                "checkpoint": str(row.get("Checkpoint", "")).strip(),
            })
        
        logger.info(f"Loaded {len(checkpoints)} checkpoints from blob storage")
        return checkpoints
    
    except Exception as e:
        logger.error(f"Failed to load checkpoints: {e}")
        raise
