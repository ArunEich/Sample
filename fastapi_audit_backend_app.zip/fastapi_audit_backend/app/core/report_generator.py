# backend/app/core/report_generator.py (this is a dummy placeholder file)
from docx import Document
from io import BytesIO

def generate_report(filename: str, summary: dict, results: list) -> BytesIO:
    """Generate a DOCX report containing the audit summary and results."""
    doc = Document()
    doc.add_heading('Validation Summary Report', 0)
    doc.add_paragraph(f"Original File: {filename}")
    doc.add_paragraph(f"Generated on: {summary['timestamp']}")

    doc.add_heading('Audit Summary', level=1)
    doc.add_paragraph(f"Total Checkpoints: {summary['total_checkpoints']}")
    doc.add_paragraph(f"Passed: {summary['passed']}")
    doc.add_paragraph(f"Failed: {summary['failed']}")

    doc.add_heading('Checkpoint Results', level=1)
    table = doc.add_table(rows=1, cols=4)
    headers = table.rows[0].cells
    headers[0].text = 'Serial'
    headers[1].text = 'Checkpoint'
    headers[2].text = 'Status'
    headers[3].text = 'Recommendation'

    for result in results:
        row = table.add_row().cells
        row[0].text = str(result['Serial'])
        row[1].text = result['Checkpoint']
        row[2].text = result['Status']
        row[3].text = result['Recommendation']

    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)

    return buf
