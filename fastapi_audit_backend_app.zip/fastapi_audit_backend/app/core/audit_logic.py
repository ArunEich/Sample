# backend/app/core/audit_logic.py (this is a dummy placeholder file)
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from app.services.ai_service import AIService
from app.services.docintelligence_service import DocIntelligenceService
from app.config import settings
import math

logger = logging.getLogger(__name__)

ai_service = AIService()
docint_service = DocIntelligenceService()

def chunk_text(text: str, max_chars: int = 1000, overlap: int = 300):
    """Chunks text for processing with a maximum character limit and overlap."""
    if not text:
        return []
    
    chunks = []
    start = 0
    length = len(text)
    
    while start < length:
        end = min(start + max_chars, length)
        chunks.append(text[start:end])
        if end == length:
            break
        start = end - overlap
    
    return chunks

def extract_text_from_document_bytes(file_bytes: bytes, file_ext: str) -> str:
    """Extract text from document using Azure Document Intelligence (PDF) or python-docx (DOCX)."""
    if file_ext == "pdf":
        return docint_service.extract_text_from_pdf(file_bytes)
    else:
        return docint_service.extract_text_from_docx(file_bytes)

def verify_checkpoints_with_ai(checkpoints: list, file_bytes: bytes, file_ext: str) -> list:
    """Verify checkpoints using AI against document content."""
    raw_text = extract_text_from_document_bytes(file_bytes, file_ext)
    chunks = chunk_text(raw_text, max_chars=settings.MAX_TOKENS * 4, overlap=settings.OVERLAP)
    
    results = []
    with ThreadPoolExecutor(max_workers=settings.MAX_CONCURRENCY) as executor:
        futures = {}
        for checkpoint in checkpoints:
            doc_excerpt = chunks[0] if chunks else ""
            futures[executor.submit(ai_service.evaluate_checkpoint, checkpoint['checkpoint'], doc_excerpt)] = checkpoint
        
        for future in as_completed(futures):
            checkpoint = futures[future]
            try:
                result = future.result()
                results.append({
                    "Serial": checkpoint['serial'],
                    "Checkpoint": checkpoint['checkpoint'],
                    "Status": result['status'],
                    "Recommendation": result['recommendation']
                })
            except Exception as e:
                logger.error(f"Failed to evaluate checkpoint {checkpoint['serial']}: {e}")
                results.append({
                    "Serial": checkpoint['serial'],
                    "Checkpoint": checkpoint['checkpoint'],
                    "Status": "Fail",
                    "Recommendation": f"Error: {str(e)}"
                })
    
    return sorted(results, key=lambda r: r['Serial'])
