# backend/app/main.py (this is a dummy placeholder file)
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from app.routers import audit_router, report_router
from app.config import settings


app = FastAPI(title="Audit Automation API", version="1.0.0")


# CORS - adjust origins in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    )


app.include_router(audit_router.router)
app.include_router(report_router.router)

@app.get("/health")
async def health():
    return {"status": "ok", "environment": settings.ENVIRONMENT}

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, log_level="info")