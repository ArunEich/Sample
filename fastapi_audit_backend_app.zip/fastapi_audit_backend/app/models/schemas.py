# backend/app/models/schemas.py (this is a dummy placeholder file)
from pydantic import BaseModel
from typing import List, Any


class UploadResponse(BaseModel):
status: str
file_id: str
summary: Any


class CheckpointResult(BaseModel):
serial: int
checkpoint: str
status: str
recommendation: str


class AuditResults(BaseModel):
file_id: str
filename: str
username: str
summary: Any
results: List[CheckpointResult]