import logging
import azure.functions as func
from .processor import process_audit_task

logger = logging.getLogger(__name__)

def main(msg: func.ServiceBusMessage):
    try:
        # Parse the message body (metadata sent from FastAPI)
        file_info = msg.get_body().decode("utf-8")
        process_audit_task(file_info)
    except Exception as e:
        logger.error(f"Failed to process message: {str(e)}")
        raise e