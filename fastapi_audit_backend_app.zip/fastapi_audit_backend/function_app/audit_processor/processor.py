import logging
import json
from azure.storage.blob import BlobServiceClient
from azure.servicebus import ServiceBusClient
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from app.config import settings
from app.core.checkpoint_loader import load_checkpoints
from app.core.audit_logic import verify_checkpoints_with_ai
from app.core.report_generator import generate_report
from app.services.blob_service import BlobService
from app.services.servicebus import ServiceBusPublisher
import uuid
import os

logger = logging.getLogger(__name__)

# Initialize services
blob_service = BlobService()
publisher = ServiceBusPublisher()

def process_audit_task(file_info: str):
    """
    This function is triggered by the Service Bus message.
    It processes the audit task by downloading the file from Azure Blob Storage,
    analyzing it, and uploading the results.
    """
    try:
        # Parse the message info (contains file_id, username, etc.)
        file_info = json.loads(file_info)
        file_id = file_info['file_id']
        blob_path = file_info['blob_path']
        username = file_info['username']
        filename = file_info['filename']

        # Step 1: Download the file from Azure Blob Storage
        file_bytes = blob_service.download_bytes(settings.BLOB_CONTAINER_UPLOADS, blob_path)

        # Step 2: Load predefined audit checkpoints (rules) from Blob Storage
        checkpoints = load_checkpoints()

        # Step 3: Run the audit logic to verify checkpoints against the document content
        # This uses the same logic as in FastAPI backend
        audit_results = verify_checkpoints_with_ai(checkpoints, file_bytes, filename.split('.')[-1])

        # Step 4: Generate the audit report (DOCX)
        report_buf = generate_report(filename, {"total_checkpoints": len(checkpoints), "passed": 0, "failed": 0}, audit_results)
        report_path = os.path.join('/tmp', f'report_{file_id}.docx')
        with open(report_path, 'wb') as f:
            f.write(report_buf.getvalue())

        # Step 5: Upload the generated report to Azure Blob Storage
        blob_service.upload_bytes(settings.BLOB_CONTAINER_RESULTS, f"results/{file_id}/report.docx", open(report_path, 'rb').read())

        # Step 6: Send a message to Service Bus indicating that the task is complete
        message = {
            'status': 'completed',
            'file_id': file_id,
            'report_link': f"{settings.BLOB_CONTAINER_RESULTS}/results/{file_id}/report.docx"
        }
        publisher.publish(message)

        logger.info(f"Audit task completed successfully for file_id: {file_id}")
    except Exception as e:
        logger.error(f"Failed to process audit task for file_id {file_id}: {str(e)}")
        raise e
