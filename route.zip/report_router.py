
from fastapi import APIRouter, HTTPException
 
from fastapi.responses import FileResponse, JSONResponse
from backend.core.logger import log_upload, init_log_file, load_upload_logs
from fastapi import FastAPI, File, UploadFile, HTTPException, Form, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import os
import shutil
from typing import Optional
from datetime import datetime
import pandas as pd
import json
 
# router = APIRouter(prefix="/report", tags=["Report"])
 
# OUTPUT_DIR = os.path.join(os.getcwd(), "output")
 
# # View detailed results / summary
 
# @router.get("/view/{file_id}")
 
# async def view_report(file_id: str):
 
#     """Return detailed results (summary + checkpoints) as JSON"""

#     print("report generated successfully 5")
#     results_path = os.path.join(OUTPUT_DIR, f"results_{file_id}.json")
#     print("jyothi",{results_path})
#     if not os.path.exists(results_path):
 
#         raise HTTPException(status_code=404, detail="Results not found")
 
#     with open(results_path, "r") as f:
 
#         results_data = json.load(f)
 
#     return JSONResponse(content=results_data)
# print("report generated successfully")
# # Download generated report
 
# @router.get("/download/{file_id}")
 
# async def download_report(file_id: str):
 
#     """Download the report as .docx"""
 
#     report_path = os.path.join(OUTPUT_DIR, f"report_{file_id}.docx")
 
#     if not os.path.exists(report_path):
 
#         raise HTTPException(status_code=404, detail="Report not found")
 
#     return FileResponse(
 
#         report_path,
 
#         media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
 
#         filename=f"Validation_Report_{file_id}.docx"
 
#     )
 
# @router.get("/dashboard")
# async def get_user_uploads(username: Optional[str] = Query(None)):
#     """Get upload history for a specific user or all users"""
#     df_records = load_upload_logs()
 
#     if username:
#         user_records = df_records[df_records["User"] == username]
#         data = user_records.to_dict('records') if not user_records.empty else []
#     else:
#         data = df_records.to_dict('records') if not df_records.empty else []
 
#     return JSONResponse(content={"dashboard": data})
 
 
# # Health check endpoint
# @router.get("/health")
# async def health_check():
#     """Simple health check for the report router"""
#     return JSONResponse(content={
#         "status": "healthy",
#         "timestamp": datetime.now().isoformat()
#     })
 
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse
from azure.storage.blob import BlobServiceClient
import os
import json
from typing import Optional
from datetime import datetime
import tempfile

# Initialize router
router = APIRouter(prefix="/report", tags=["Report"])

# Environment variables for Azure Blob Storage
BLOB_CONN_STR = os.getenv("AZURE_BLOB_CONN_STR")
BLOB_CONTAINER = os.getenv("BLOB_CONTAINER", "genaipoc")

# Initialize Blob Service Client
blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
container_client = blob_service.get_container_client(BLOB_CONTAINER)

# -----------------------------
# Endpoint: View detailed results
# -----------------------------
@router.get("/view/{file_id}")
async def view_report(file_id: str):
    """Return detailed results (summary + checkpoints) as JSON from Blob Storage"""
    blob_name = f"results/results_{file_id}.json"
    # blob_name= f"uploads/jyo_20251113_105637_2129bbc1_Sample_1.0.docx"
    print("Hi")
    try:
        blob_client = container_client.get_blob_client(blob_name)
        print("check")
        stream = blob_client.download_blob()
        results_data = json.loads(stream.readall())
        return JSONResponse(content=results_data)
        
        # # Read a small chunk to confirm download works
        # data = stream.readall()  # Or stream.readinto() for large files
        # print(f"Downloaded {len(data)} bytes")
        
        # return {"message": "File downloaded successfully", "size": len(data)}
    except Exception:
        raise HTTPException(status_code=404, detail="Results not found in Blob Storage")


# -----------------------------
# Endpoint: Download generated report
# -----------------------------
@router.get("/download/{file_id}")
async def download_report(file_id: str):
    """Download the report as .docx from Blob Storage"""
    blob_name = f"reports/report_{file_id}.docx"
    print("Hi_1")
    try:
        blob_client = container_client.get_blob_client(blob_name)
        stream = blob_client.download_blob()

        # Save to temporary file for FileResponse
        temp_dir = tempfile.gettempdir()
        temp_path = os.path.join(temp_dir, f"report_{file_id}.docx")
        with open(temp_path, "wb") as f:
            f.write(stream.readall())

        return FileResponse(
            temp_path,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            filename=f"Validation_Report_{file_id}.docx"
        )
    except Exception:
        raise HTTPException(status_code=404, detail="Report not found in Blob Storage")

# -----------------------------
# Endpoint: Dashboard - Get upload history
# -----------------------------
@router.get("/dashboard")
async def get_user_uploads(username: Optional[str] = Query(None)):
    """Get upload history for a specific user or all users from Blob Storage"""
    try:
        # Assuming logs are stored in blob as logs/upload_logs.json
        blob_name = "logs/upload_logs.json"
        print("hi_2")
        blob_client = container_client.get_blob_client(blob_name)
        stream = blob_client.download_blob()
        logs_data = json.loads(stream.readall())

        if username:
            user_records = [record for record in logs_data if record.get("User") == username]
            data = user_records
        else:
            data = logs_data

        return JSONResponse(content={"dashboard": data})
    except Exception:
        # If logs not found, return empty dashboard
        return JSONResponse(content={"dashboard": []})

# -----------------------------
# Endpoint: Health Check
# -----------------------------
@router.get("/health")
async def health_check():
    """Simple health check for the report router"""
    return JSONResponse(content={
        "status": "healthy",
        "timestamp": datetime.now().isoformat()
    })