# # import azure.functions as func
# # import datetime
# # import json
# # import logging

# # from backend.main import app as app1
# # app = func.AsgiFunctionApp(app=app1,function_name="demo",http_auth_level=func.AuthLevel.ANONYMOUS)

# #function_app.py
# import json
# import logging
# import os
# from datetime import datetime
# from azure.storage.blob import BlobServiceClient
# import azure.functions as func
# from backend.core.document_extractor import extract_text_with_docintelligence
# from backend.core.checkpoint_loader import load_checkpoints_from_blob
# from backend.core.audit_logic import verify_checkpoints_with_ai
# from backend.core.report_generator import generate_report

# app = func.FunctionApp()

# # Environment variables
# BLOB_CONN_STR = os.getenv("AZURE_BLOB_CONN_STR")
# BLOB_CONTAINER = os.getenv("BLOB_CONTAINER", "genaipoc")

# blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
# container_client = blob_service.get_container_client(BLOB_CONTAINER)

# @app.function_name(name="ProcessAuditMessage")
# @app.service_bus_queue_trigger(arg_name="msg", queue_name=os.getenv("SERVICE_BUS_QUEUE"), connection="AZURE_SERVICE_BUS_CONN_STR")
# def main(msg: func.ServiceBusMessage):
#     try:
#         # Parse message
#         message_body = msg.get_body().decode("utf-8")
#         data = json.loads(message_body)
#         logging.info(f"Received message for file_id={data.get('file_id')}")

#         blob_name = data["blob_name"]
#         filename = data["filename"]
#         file_id = data["file_id"]

#         # Download file from Blob
#         blob_client = container_client.get_blob_client(blob_name)
#         file_bytes = blob_client.download_blob().readall()
#         ext = filename.lower().split(".")[-1]

#         # Extract text
#         full_text = extract_text_with_docintelligence(file_bytes, ext)

#         # Load checkpoints
#         checkpoints = load_checkpoints_from_blob()

#         # Verify checkpoints
#         results = verify_checkpoints_with_ai(checkpoints, full_text, file_bytes, ext)

#         # Summary
#         summary = {
#             "total_checkpoints": len(checkpoints),
#             "passed": sum(1 for r in results if r["Status"] == "Pass"),
#             "failed": sum(1 for r in results if r["Status"] == "Fail")
#         }

#         # Generate report
#         report_buf = generate_report(filename, summary, results)
#         container_client.upload_blob(f"reports/report_{file_id}.docx", report_buf.getvalue(), overwrite=True)

#         # Upload results JSON
#         results_json = {
#             "file_id": file_id,
#             "summary": summary,
#             "results": results,
#             "timestamp": datetime.now().isoformat(),
#         }
#         container_client.upload_blob(f"results/results_{file_id}.json", json.dumps(results_json, indent=2), overwrite=True)

#         logging.info(f"✅ Processing completed for {filename}")

#     except Exception as e:
#         logging.error(f"❌ Error processing message: {e}", exc_info=True)

import json
import logging
import os
from datetime import datetime
from azure.storage.blob import BlobServiceClient
import azure.functions as func
from backend.core.document_extractor import extract_text_with_docintelligence
from backend.core.checkpoint_loader import load_checkpoints_from_blob
from backend.core.audit_logic import verify_checkpoints_with_ai
from backend.core.report_generator import generate_report

app = func.FunctionApp()

# Environment variables
BLOB_CONN_STR = os.getenv("AZURE_BLOB_CONN_STR")
BLOB_CONTAINER = os.getenv("BLOB_CONTAINER", "genaipoc")

# Initialize Blob Service Client
blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)
container_client = blob_service.get_container_client(BLOB_CONTAINER)

@app.function_name(name="ProcessAuditMessage")
@app.service_bus_queue_trigger(arg_name="msg", queue_name=os.getenv("SERVICE_BUS_QUEUE"), connection="AZURE_SERVICE_BUS_CONN_STR")
def main(msg: func.ServiceBusMessage):
    try:
        # Parse message
        message_body = msg.get_body().decode("utf-8")
        data = json.loads(message_body)
        file_id = data.get("file_id")
        filename = data.get("filename")
        blob_name = data.get("blob_name")

        logging.info(f"📩 Received message for file_id={file_id}, blob_name={blob_name}")
        print("Hi_22")
        # Download file from Blob
        try:
            logging.info(f"Downloading file from Blob: {blob_name}")
            print("jyothi")
            blob_client = container_client.get_blob_client(blob_name)
            file_bytes = blob_client.download_blob().readall()
            logging.info(f"✅ File downloaded successfully: {filename}")
        except Exception as e:
            logging.error(f"❌ Failed to download file from Blob: {e}", exc_info=True)
            return {"status": "error", "blob_name": blob_name}

        # Extract text
        ext = filename.lower().split(".")[-1]
        try:
            logging.info(f"Extracting text using Document Intelligence for extension: {ext}")
            full_text = extract_text_with_docintelligence(file_bytes, ext)
            logging.info("✅ Text extraction completed")
        except Exception as e:
            logging.error(f"❌ Text extraction failed: {e}", exc_info=True)
            return {"status": "error", "step": "text_extraction"}

        # Load checkpoints
        try:
            logging.info("Loading checkpoints from Blob")
            checkpoints = load_checkpoints_from_blob()
            logging.info(f"✅ Loaded {len(checkpoints)} checkpoints")
        except Exception as e:
            logging.error(f"❌ Failed to load checkpoints: {e}", exc_info=True)
            return

        # Verify checkpoints
        try:
            logging.info("Verifying checkpoints with AI")
            results = verify_checkpoints_with_ai(checkpoints, full_text, file_bytes, ext)
            logging.info(f"✅ Verification completed: {len(results)} results")
        except Exception as e:
            logging.error(f"❌ Checkpoint verification failed: {e}", exc_info=True)
            return {"status": "error", "step": "verify_checkpoints"}

        # Summary
        summary = {
            "total_checkpoints": len(checkpoints),
            "passed": sum(1 for r in results if r["Status"] == "Pass"),
            "failed": sum(1 for r in results if r["Status"] == "Fail")
        }
        logging.info(f"Summary: {summary}")

        # Generate report
        try:
            logging.info("Generating report DOCX")
            report_buf = generate_report(filename, summary, results)
            print("Hi12334")
            logging.info("✅ Report generated successfully")
        except Exception as e:
            logging.error(f"❌ Report generation failed: {e}", exc_info=True)
            return {"status": "error"}

        # Upload report DOCX
        try:
            logging.info(f"Uploading report to Blob: reports/report_{file_id}.docx")
            container_client.upload_blob(
                f"reports/report_{file_id}.docx",
                report_buf.getvalue(),
                overwrite=True
            )
            logging.info(f"✅ Uploaded report DOCX for {file_id}")
        except Exception as e:
            logging.error(f"❌ Failed to upload report DOCX: {e}", exc_info=True)

        # Upload results JSON
        results_json = {
            "file_id": file_id,
            "summary": summary,
            "results": results,
            "timestamp": datetime.now().isoformat(),
        }
        try:
            logging.info(f"Uploading results to Blob: results/results_{file_id}.json")
            print("hello")
            container_client.upload_blob(
                f"results/results_{file_id}.json",
                json.dumps(results_json, indent=2),
                overwrite=True
            )
            logging.info(f"✅ Uploaded results JSON for {file_id}")
        except Exception as e:
            logging.error(f"❌ Failed to upload results JSON: {e}", exc_info=True)

        logging.info(f"✅ Processing completed for {filename}")

    except Exception as e:
        logging.error(f"❌ Unexpected error: {e}", exc_info=True)