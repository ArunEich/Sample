# # backend/routers/audit_router.py
# from fastapi import APIRouter, UploadFile, File, Form, HTTPException
# from fastapi.responses import JSONResponse
# import os
# import json
# from datetime import datetime

# from backend.core.logger import log_upload, init_log_file
# from backend.core.checkpoint_loader import load_checkpoints
# from backend.core.document_extractor import extract_pdf_content, extract_docx_content
# from backend.core.audit_logic import verify_checkpoints_with_ai
# from backend.core.report_generator import generate_report
# from backend.utils.file_ops import convert_docx_to_pdf_bytes, save_pdf_images

# router = APIRouter(prefix="/audit", tags=["Audit"])

# UPLOAD_DIR = os.path.join(os.getcwd(), "uploads")
# OUTPUT_DIR = os.path.join(os.getcwd(), "output")
# IMAGES_DIR = os.path.join(os.getcwd(), "saved_images")

# for d in (UPLOAD_DIR, OUTPUT_DIR, IMAGES_DIR):
#     os.makedirs(d, exist_ok=True)

# @router.post("/run")
# async def run_audit(username: str = Form(...), file: UploadFile = File(...)):
#     if not file.filename.lower().endswith((".pdf", ".docx")):
#         raise HTTPException(status_code=400, detail="Only PDF and DOCX are supported")

#     # store upload
#     timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#     file_id = f"{username}_{timestamp}_{file.filename}"
#     upload_path = os.path.join(UPLOAD_DIR, file_id)
#     with open(upload_path, "wb") as f:
#         f.write(await file.read())

#     # read back bytes (to support further processing)
#     with open(upload_path, "rb") as f:
#         file_bytes = f.read()

#     ext = file.filename.lower().split(".")[-1]
#     if ext == "pdf":
#         full_text = extract_pdf_content(file_bytes)
#     else:
#         full_text = extract_docx_content(file_bytes)

#     checkpoints = load_checkpoints()
#     results = await verify_checkpoints_with_ai(checkpoints, full_text, file_bytes, ext)

#     pass_count = sum(1 for r in results if r["Status"] == "Pass")
#     fail_count = sum(1 for r in results if r["Status"] == "Fail")
#     summary = {
#         "total_checkpoints": len(checkpoints),
#         "passed": pass_count,
#         "failed": fail_count
#     }

#     # Save report
#     report_buf = generate_report(file.filename, summary, results)
#     report_path = os.path.join(OUTPUT_DIR, f"report_{file_id}.docx")
#     with open(report_path, "wb") as f:
#         f.write(report_buf.getvalue())

#     # Convert docx->pdf then save images (if needed)
#     try:
#         if ext == "pdf":
#             pdf_bytes = file_bytes
#         else:
#             pdf_bytes = convert_docx_to_pdf_bytes(file_bytes)
#         if pdf_bytes:
#             save_pdf_images(pdf_bytes, IMAGES_DIR, file_id.replace(".", "_"))
#     except Exception:
#         # don't fail whole request if image extraction fails
#         pass

#     # Log upload
#     init_log_file()
#     log_upload(username, file.filename)

#     # persist results JSON for retrieval
#     results_data = {
#         "file_id": file_id,
#         "filename": file.filename,
#         "username": username,
#         "summary": summary,
#         "results": results,
#         "timestamp": datetime.now().isoformat()
#     }
#     with open(os.path.join(OUTPUT_DIR, f"results_{file_id}.json"), "w") as f:
#         json.dump(results_data, f, indent=2)

#     return JSONResponse(content={"status": "success", "file_id": file_id, "summary": summary})
#backend/routers/audit_router.py
from fastapi import APIRouter, UploadFile, File, Form, HTTPException

from fastapi.responses import JSONResponse

import os
from dotenv import load_dotenv
load_dotenv()  # loads variables from .env
import json

import traceback

from datetime import datetime

from azure.storage.blob import BlobServiceClient

from azure.servicebus import ServiceBusClient, ServiceBusMessage

import uuid
 
router = APIRouter(prefix="/audit", tags=["Audit"])
 
# Environment configuration

BLOB_CONN_STR = os.getenv("AZURE_BLOB_CONN_STR")

BLOB_CONTAINER = os.getenv("BLOB_CONTAINER", "genaipoc")

SERVICE_BUS_CONN_STR = os.getenv("AZURE_SERVICE_BUS_CONN_STR")

SERVICE_BUS_QUEUE = os.getenv("SERVICE_BUS_QUEUE", "sbqu-ai-az-eus-gda-sbx")
 
# Initialize clients

blob_service = BlobServiceClient.from_connection_string(BLOB_CONN_STR)

container_client = blob_service.get_container_client(BLOB_CONTAINER)
 
# Service Bus client

sb_client = ServiceBusClient.from_connection_string(SERVICE_BUS_CONN_STR, logging_enable=True)
 
 
@router.post("/run")

async def run_audit(username: str = Form(...), file: UploadFile = File(...)):

    """

    Step 1: Receives uploaded file from frontend.

    Step 2: Uploads file to Azure Blob Storage.

    Step 3: Sends metadata message to Service Bus to trigger Function.

    """
 
    try:

        # --------------------------------------------------------

        # 1️⃣ Validate file type

        # --------------------------------------------------------

        if not file.filename.lower().endswith((".pdf", ".docx")):

            raise HTTPException(status_code=400, detail="Only PDF and DOCX are supported")
 
        # --------------------------------------------------------

        # 2️⃣ Generate unique IDs and blob path

        # --------------------------------------------------------

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        file_id = f"{username}_{timestamp}_{uuid.uuid4().hex[:8]}"

        blob_name = f"uploads/{file_id}_{file.filename}"
 
        # --------------------------------------------------------

        # 3️⃣ Upload to Blob Storage

        # --------------------------------------------------------

        file_bytes = await file.read()

        try:

            blob_client = container_client.get_blob_client(blob_name)

            blob_client.upload_blob(file_bytes, overwrite=True)

            blob_url = blob_client.url

        except Exception as e:

            raise HTTPException(status_code=500, detail=f"Failed to upload to Blob: {e}")
 
        # --------------------------------------------------------

        # 4️⃣ Prepare message for Service Bus

        # --------------------------------------------------------

        message_data = {

            "file_id": file_id,

            "username": username,

            "filename": file.filename,

            "blob_container": BLOB_CONTAINER,

            "blob_name": blob_name,

            "blob_url": blob_url,

            "timestamp": timestamp,

            "processing_endpoint": "audit-checkpoints-v1",

        }
 
        try:

            with sb_client:

                sender = sb_client.get_queue_sender(queue_name=SERVICE_BUS_QUEUE)

                with sender:

                    message = ServiceBusMessage(json.dumps(message_data))

                    sender.send_messages(message)

        except Exception as e:

            raise HTTPException(status_code=500, detail=f"Failed to send Service Bus message: {e}")
 
        # --------------------------------------------------------

        # ✅ 5️⃣ Return response to frontend

        # --------------------------------------------------------

        return JSONResponse(

            content={

                "status": "success",

                "message": "File uploaded and processing message sent.",

                "file_id": file_id,

                "blob_url": blob_url,

                "service_bus_queue": SERVICE_BUS_QUEUE,

            }

        )
 
    # --------------------------------------------------------

    # ❌ Global exception handler (JSON guaranteed)

    # --------------------------------------------------------

    except HTTPException as e:

        return JSONResponse(

            status_code=e.status_code,

            content={"status": "error", "detail": e.detail},

        )

    except Exception as e:

        err_trace = traceback.format_exc()

        print(f"[ERROR] {e}\n{err_trace}")

        return JSONResponse(

            status_code=500,

            content={"status": "error", "message": str(e), "trace": err_trace},

        )

 