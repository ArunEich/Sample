# backend/utils/file_ops.py
import os
import subprocess
import tempfile
import platform
from io import BytesIO
from PIL import Image
import fitz  # PyMuPDF
import shutil

def convert_docx_to_pdf_bytes(file_bytes: bytes):
    """Convert DOCX bytes to PDF bytes using LibreOffice (must be installed on the host)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        docx_path = os.path.join(tmpdir, "temp.docx")
        pdf_path = os.path.join(tmpdir, "temp.pdf")
        with open(docx_path, "wb") as f:
            f.write(file_bytes)

        # detect libreoffice/soffice
        soffice = None
        if platform.system() == "Windows":
            soffice = shutil.which("soffice") or r"C:\Program Files\LibreOffice\program\soffice.exe"
        else:
            soffice = shutil.which("libreoffice") or shutil.which("soffice")

        if not soffice:
            raise RuntimeError("LibreOffice not found on system. Install it to convert DOCX -> PDF.")

        subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", tmpdir, docx_path], check=True)

        if not os.path.exists(pdf_path):
            raise FileNotFoundError("Failed to generate PDF from DOCX using LibreOffice")

        with open(pdf_path, "rb") as f:
            return f.read()

def pdf_bytes_to_images(pdf_bytes: bytes, dpi: int = 150):
    """Return a list of PIL.Image objects for each page in the PDF."""
    images = []
    pdf = fitz.open(stream=pdf_bytes, filetype="pdf")
    for page_num in range(len(pdf)):
        page = pdf[page_num]
        pix = page.get_pixmap(dpi=dpi)
        img = Image.frombytes("RGBA", [pix.width, pix.height], pix.tobytes())
        images.append(img.convert("RGB"))
    pdf.close()
    return images

def save_pdf_images(pdf_bytes: bytes, output_dir: str, file_prefix: str, dpi: int = 150):
    """Save each PDF page as PNG into output_dir and return list of paths."""
    os.makedirs(output_dir, exist_ok=True)
    pdf = fitz.open(stream=pdf_bytes, filetype="pdf")
    saved = []
    for i in range(len(pdf)):
        page = pdf[i]
        pix = page.get_pixmap(dpi=dpi)
        out_path = os.path.join(output_dir, f"{file_prefix}_page_{i+1}.png")
        pix.save(out_path)
        saved.append(out_path)
    pdf.close()
    return saved
