# backend/function_app/main1.py
import os
import azure.functions as func
from azure.functions import AsgiMiddleware
from backend.main import app  # the FastAPI ASGI app

# The Functions host will call into this module. You will need an `__init__.py` and function.json for binding.
asgi_app = AsgiMiddleware(app)
