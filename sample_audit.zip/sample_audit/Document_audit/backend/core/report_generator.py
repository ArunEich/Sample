# backend/core/report_generator.py
from docx import Document as DocxDocument
from docx.shared import RGBColor
from io import BytesIO
from datetime import datetime

def generate_report(document_name: str, summary: dict, results: list):
    report = DocxDocument()
    report.add_heading("Document Validation Report", 0)
    report.add_paragraph(f"Document: {document_name}")
    report.add_paragraph(f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.add_heading("Summary", level=1)
    report.add_paragraph(f"Total Checkpoints: {summary['total_checkpoints']}")
    report.add_paragraph(f"Passed: {summary['passed']}")
    report.add_paragraph(f"Failed: {summary['failed']}")

    report.add_heading("Detailed Results", level=1)
    table = report.add_table(rows=1, cols=4)
    hdr = table.rows[0].cells
    hdr[0].text = "S.No"
    hdr[1].text = "Checkpoint"
    hdr[2].text = "Status"
    hdr[3].text = "Recommendation"

    for r in results:
        row_cells = table.add_row().cells
        row_cells[0].text = str(r.get("S.No", ""))
        row_cells[1].text = r.get("Checkpoint", "")
        row_cells[2].text = r.get("Status", "")
        row_cells[3].text = r.get("Recommendation", "")

        try:
            if r.get("Status") == "Pass":
                row_cells[2].paragraphs[0].runs[0].font.color.rgb = RGBColor(0, 128, 0)
            else:
                row_cells[2].paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 0, 0)
        except Exception:
            pass

    buf = BytesIO()
    report.save(buf)
    buf.seek(0)
    return buf
