
from fastapi import APIRouter, HTTPException
 
from fastapi.responses import FileResponse, JSONResponse
from backend.core.logger import log_upload, init_log_file, load_upload_logs
from fastapi import FastAPI, File, UploadFile, HTTPException, Form, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import os
import shutil
from typing import Optional
from datetime import datetime
import pandas as pd
import json
 
router = APIRouter(prefix="/report", tags=["Report"])
 
OUTPUT_DIR = os.path.join(os.getcwd(), "output")
 
# View detailed results / summary
 
@router.get("/view/{file_id}")
 
async def view_report(file_id: str):
 
    """Return detailed results (summary + checkpoints) as JSON"""
 
    results_path = os.path.join(OUTPUT_DIR, f"results_{file_id}.json")
 
    if not os.path.exists(results_path):
 
        raise HTTPException(status_code=404, detail="Results not found")
 
    with open(results_path, "r") as f:
 
        results_data = json.load(f)
 
    return JSONResponse(content=results_data)
 
# Download generated report
 
@router.get("/download/{file_id}")
 
async def download_report(file_id: str):
 
    """Download the report as .docx"""
 
    report_path = os.path.join(OUTPUT_DIR, f"report_{file_id}.docx")
 
    if not os.path.exists(report_path):
 
        raise HTTPException(status_code=404, detail="Report not found")
 
    return FileResponse(
 
        report_path,
 
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
 
        filename=f"Validation_Report_{file_id}.docx"
 
    )
 
@router.get("/dashboard")
async def get_user_uploads(username: Optional[str] = Query(None)):
    """Get upload history for a specific user or all users"""
    df_records = load_upload_logs()
 
    if username:
        user_records = df_records[df_records["User"] == username]
        data = user_records.to_dict('records') if not user_records.empty else []
    else:
        data = df_records.to_dict('records') if not df_records.empty else []
 
    return JSONResponse(content={"dashboard": data})
 
 
# Health check endpoint
@router.get("/health")
async def health_check():
    """Simple health check for the report router"""
    return JSONResponse(content={
        "status": "healthy",
        "timestamp": datetime.now().isoformat()
    })
 
 