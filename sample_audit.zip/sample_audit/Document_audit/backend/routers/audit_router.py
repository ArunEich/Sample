# backend/routers/audit_router.py
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
import os
import json
from datetime import datetime

from backend.core.logger import log_upload, init_log_file
from backend.core.checkpoint_loader import load_checkpoints
from backend.core.document_extractor import extract_pdf_content, extract_docx_content
from backend.core.audit_logic import verify_checkpoints_with_ai
from backend.core.report_generator import generate_report
from backend.utils.file_ops import convert_docx_to_pdf_bytes, save_pdf_images

router = APIRouter(prefix="/audit", tags=["Audit"])

UPLOAD_DIR = os.path.join(os.getcwd(), "uploads")
OUTPUT_DIR = os.path.join(os.getcwd(), "output")
IMAGES_DIR = os.path.join(os.getcwd(), "saved_images")

for d in (UPLOAD_DIR, OUTPUT_DIR, IMAGES_DIR):
    os.makedirs(d, exist_ok=True)

@router.post("/run")
async def run_audit(username: str = Form(...), file: UploadFile = File(...)):
    if not file.filename.lower().endswith((".pdf", ".docx")):
        raise HTTPException(status_code=400, detail="Only PDF and DOCX are supported")

    # store upload
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_id = f"{username}_{timestamp}_{file.filename}"
    upload_path = os.path.join(UPLOAD_DIR, file_id)
    with open(upload_path, "wb") as f:
        f.write(await file.read())

    # read back bytes (to support further processing)
    with open(upload_path, "rb") as f:
        file_bytes = f.read()

    ext = file.filename.lower().split(".")[-1]
    if ext == "pdf":
        full_text = extract_pdf_content(file_bytes)
    else:
        full_text = extract_docx_content(file_bytes)

    checkpoints = load_checkpoints()
    results = await verify_checkpoints_with_ai(checkpoints, full_text, file_bytes, ext)

    pass_count = sum(1 for r in results if r["Status"] == "Pass")
    fail_count = sum(1 for r in results if r["Status"] == "Fail")
    summary = {
        "total_checkpoints": len(checkpoints),
        "passed": pass_count,
        "failed": fail_count
    }

    # Save report
    report_buf = generate_report(file.filename, summary, results)
    report_path = os.path.join(OUTPUT_DIR, f"report_{file_id}.docx")
    with open(report_path, "wb") as f:
        f.write(report_buf.getvalue())

    # Convert docx->pdf then save images (if needed)
    try:
        if ext == "pdf":
            pdf_bytes = file_bytes
        else:
            pdf_bytes = convert_docx_to_pdf_bytes(file_bytes)
        if pdf_bytes:
            save_pdf_images(pdf_bytes, IMAGES_DIR, file_id.replace(".", "_"))
    except Exception:
        # don't fail whole request if image extraction fails
        pass

    # Log upload
    init_log_file()
    log_upload(username, file.filename)

    # persist results JSON for retrieval
    results_data = {
        "file_id": file_id,
        "filename": file.filename,
        "username": username,
        "summary": summary,
        "results": results,
        "timestamp": datetime.now().isoformat()
    }
    with open(os.path.join(OUTPUT_DIR, f"results_{file_id}.json"), "w") as f:
        json.dump(results_data, f, indent=2)

    return JSONResponse(content={"status": "success", "file_id": file_id, "summary": summary})
